# 🎯 OI RADAR — Live Options OI Buildup Dashboard

Real-time Options OI analysis for NIFTY & BANKNIFTY on your phone.  
**Zero cost** • Upstox Free API • Vercel Free Hosting • Mobile-first dark UI

---

## 🚀 QUICK SETUP (15 minutes)

### Step 1: Upstox Developer App Setup
1. Go to [developer.upstox.com](https://developer.upstox.com)
2. Open your app (or create one)
3. Set **Redirect URI** to: `https://YOUR-APP-NAME.vercel.app/api/callback`
   - Example: `https://oi-radar.vercel.app/api/callback`
4. Note your **API Key** and **API Secret**

### Step 2: Deploy to Vercel (Free)
1. Push this code to a GitHub repository
2. Go to [vercel.com](https://vercel.com) → "Add New Project"
3. Import your GitHub repo
4. In **Environment Variables**, add:
   | Variable | Value |
   |----------|-------|
   | `UPSTOX_API_KEY` | Your API Key |
   | `UPSTOX_API_SECRET` | Your API Secret |
   | `UPSTOX_REDIRECT_URI` | `https://YOUR-APP.vercel.app/api/callback` |
   | `COOKIE_SECRET` | Any random 32-character string |
5. Click **Deploy**

### Step 3: Daily Usage
1. Open your Vercel URL on phone browser
2. Click "LOGIN WITH UPSTOX" (once per day)
3. Login with your Upstox credentials
4. Dashboard loads with live data!
5. **Add to Home Screen** for app-like experience

---

## 📱 FEATURES

- **OI Heatmap** — Strike-wise OI change visualization
- **Buildup Analysis** — Fresh Writing / Aggressive / Unwinding classification
- **Support & Resistance** — Based on max OI concentration
- **PCR Analysis** — Put-Call Ratio with gauge and interpretation
- **Max Pain** — Calculated from full option chain
- **Auto-refresh** — Every 30 seconds during market hours
- **NIFTY & BANKNIFTY** — One-tap switch

---

## 🏗️ ARCHITECTURE

```
Phone Browser
    ↓
Vercel (Free Hosting)
    ├── /app/page.js          → Mobile dashboard UI
    ├── /app/api/callback      → OAuth token exchange
    └── /app/api/oi            → Fetches Upstox option chain
                                  (server-side, no CORS issues)
    ↓
Upstox API (Free)
    └── /v2/option/chain       → Live OI, Volume, IV, Greeks
```

---

## 🔧 LOCAL DEVELOPMENT

```bash
# Clone and install
git clone <your-repo>
cd oi-radar
npm install

# Create .env.local (copy from .env.local.example)
cp .env.local.example .env.local
# Edit .env.local with your credentials
# Set redirect_uri to: http://localhost:3000/api/callback

# Run
npm run dev
# Open http://localhost:3000
```

---

## ⚡ NOTES

- Access token valid for ~22 hours (until next day ~3:30 AM IST)
- Login once every morning before market opens
- Free Upstox API has rate limits (~1 req/sec) — 30s refresh is well within
- All data stays in your browser, nothing stored on server
- Vercel free tier: unlimited pageviews, 100GB bandwidth/month

---

Built by Adi • Powered by Upstox API • Hosted on Vercel
