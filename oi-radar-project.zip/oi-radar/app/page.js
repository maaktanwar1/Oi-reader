'use client';

import { useState, useEffect, useCallback, useRef } from 'react';

// ============================================================
// FORMATTING HELPERS
// ============================================================
const fmt = (n) => {
  if (n == null) return '—';
  const abs = Math.abs(n);
  if (abs >= 10000000) return (n / 10000000).toFixed(2) + 'Cr';
  if (abs >= 100000) return (n / 100000).toFixed(2) + 'L';
  if (abs >= 1000) return (n / 1000).toFixed(1) + 'K';
  return n.toLocaleString('en-IN');
};
const fmtS = (n) => (n >= 0 ? '+' : '') + fmt(n);

// ============================================================
// STYLES (inline object for zero-config CSS)
// ============================================================
const S = {
  app: { background: '#0a0a0f', minHeight: '100vh', color: '#c9d1d9', fontFamily: "'DM Sans', -apple-system, sans-serif", maxWidth: 480, margin: '0 auto', paddingBottom: 80 },
  header: { background: 'linear-gradient(135deg, #0d1117, #161b22)', borderBottom: '1px solid #21262d', padding: '14px 16px 10px', position: 'sticky', top: 0, zIndex: 100 },
  mono: { fontFamily: "'JetBrains Mono', monospace" },
  card: { background: '#161b22', border: '1px solid #21262d', borderRadius: 10, padding: '12px 14px', textAlign: 'center', flex: 1, minWidth: 0 },
  tag: (bg, color, border) => ({ display: 'inline-block', padding: '2px 8px', borderRadius: 4, fontSize: 10, fontWeight: 600, background: bg, color, border: `1px solid ${border}` }),
  btn: (active) => ({
    background: active ? '#1f6feb' : '#21262d', color: active ? '#fff' : '#8b949e',
    border: 'none', borderRadius: 6, padding: '6px 12px', fontSize: 11, fontWeight: 600,
    cursor: 'pointer', fontFamily: "'JetBrains Mono', monospace",
  }),
  tab: (active) => ({
    flex: 1, background: active ? '#1f6feb22' : 'transparent',
    color: active ? '#58a6ff' : '#8b949e', border: 'none',
    borderBottom: active ? '2px solid #58a6ff' : '2px solid transparent',
    padding: '10px 8px', fontSize: 11, fontWeight: 700, cursor: 'pointer',
    letterSpacing: '1px', fontFamily: "'JetBrains Mono', monospace",
  }),
};

const GREEN = '#3fb950', RED = '#f85149', BLUE = '#58a6ff', YELLOW = '#d29922';

// ============================================================
// SUB-COMPONENTS
// ============================================================
function MetricCard({ label, value, color = '#c9d1d9', sub }) {
  return (
    <div style={S.card}>
      <div style={{ ...S.mono, fontSize: 20, fontWeight: 700, color, lineHeight: 1.2 }}>{value}</div>
      {sub && <div style={{ fontSize: 9, color: '#6e7681', marginTop: 1 }}>{sub}</div>}
      <div style={{ color: '#8b949e', fontSize: 9, textTransform: 'uppercase', letterSpacing: '0.8px', marginTop: 3 }}>{label}</div>
    </div>
  );
}

function OIBar({ strike, ceChange, peChange, maxChange, isATM }) {
  const ceW = Math.min(Math.abs(ceChange) / maxChange * 100, 100);
  const peW = Math.min(Math.abs(peChange) / maxChange * 100, 100);
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 3, padding: '5px 0',
      borderBottom: '1px solid #0d1117',
      background: isATM ? 'rgba(88,166,255,0.08)' : 'transparent',
      borderLeft: isATM ? '3px solid #58a6ff' : '3px solid transparent', paddingLeft: 6,
    }}>
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: 3 }}>
        <span style={{ ...S.mono, fontSize: 9, color: ceChange > 0 ? RED : '#8b949e', minWidth: 40, textAlign: 'right' }}>{fmtS(ceChange)}</span>
        <div style={{ width: 70, height: 12, background: '#1a1a2e', borderRadius: 3, overflow: 'hidden', display: 'flex', justifyContent: 'flex-end' }}>
          <div style={{ width: `${ceW}%`, height: '100%', background: ceChange > 0 ? `linear-gradient(90deg, #3d1114, ${RED})` : 'linear-gradient(90deg, #1d2d1d, #484f58)', borderRadius: 3, transition: 'width 0.3s' }} />
        </div>
      </div>
      <div style={{ minWidth: 48, textAlign: 'center', ...S.mono, fontSize: 10, fontWeight: isATM ? 700 : 500, color: isATM ? BLUE : '#c9d1d9', lineHeight: 1 }}>
        {strike}
        {isATM && <div style={{ fontSize: 6, color: BLUE, marginTop: 1 }}>● ATM</div>}
      </div>
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 3 }}>
        <div style={{ width: 70, height: 12, background: '#1a1a2e', borderRadius: 3, overflow: 'hidden' }}>
          <div style={{ width: `${peW}%`, height: '100%', background: peChange > 0 ? `linear-gradient(270deg, ${GREEN}, #0d3321)` : 'linear-gradient(270deg, #484f58, #1d2d1d)', borderRadius: 3, transition: 'width 0.3s' }} />
        </div>
        <span style={{ ...S.mono, fontSize: 9, color: peChange > 0 ? GREEN : '#8b949e', minWidth: 40 }}>{fmtS(peChange)}</span>
      </div>
    </div>
  );
}

function BuildupRow({ strike, type, change, oi, signal }) {
  const c = signal === 'FRESH WRITING' ? { bg: '#0d3321', b: '#238636', t: GREEN }
    : signal === 'AGGRESSIVE' ? { bg: '#3d1114', b: '#da3633', t: RED }
    : { bg: '#2d1f00', b: '#9e6a03', t: YELLOW };
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 12px', background: '#161b22', borderRadius: 8, marginBottom: 5, border: `1px solid ${c.b}33` }}>
      <div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ ...S.mono, fontSize: 14, fontWeight: 700 }}>{strike}</span>
          <span style={S.tag(type === 'CE' ? '#3d111433' : '#0d332133', type === 'CE' ? RED : GREEN, 'transparent')}>{type}</span>
        </div>
        <div style={{ fontSize: 10, color: '#8b949e', marginTop: 2 }}>OI: {fmt(oi)}</div>
      </div>
      <div style={{ textAlign: 'right' }}>
        <span style={S.tag(c.bg, c.t, c.b)}>{signal}</span>
        <div style={{ ...S.mono, fontSize: 10, color: c.t, marginTop: 3 }}>{fmtS(change)}</div>
      </div>
    </div>
  );
}

function SRLevel({ strike, oi, change, distance, type }) {
  const color = type === 'support' ? GREEN : RED;
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px 12px', background: '#161b22', borderRadius: 6, marginBottom: 4, borderLeft: `3px solid ${color}` }}>
      <div>
        <span style={{ ...S.mono, fontSize: 14, fontWeight: 700 }}>{strike}</span>
        <span style={{ fontSize: 10, color: '#8b949e', marginLeft: 8 }}>{distance}%</span>
      </div>
      <div style={{ textAlign: 'right' }}>
        <span style={{ ...S.mono, fontSize: 12, color }}>{fmt(oi)}</span>
        <span style={{ fontSize: 10, color: change > 0 ? color : '#8b949e', marginLeft: 6 }}>{fmtS(change)}</span>
      </div>
    </div>
  );
}

function PCRGauge({ pcr }) {
  const angle = Math.min(Math.max((pcr - 0.5) / 1.0 * 180, 0), 180);
  const label = pcr > 1.2 ? 'OVERSOLD' : pcr > 0.9 ? 'BULLISH' : pcr > 0.7 ? 'NEUTRAL' : 'BEARISH';
  const c = pcr > 0.9 ? GREEN : pcr > 0.7 ? YELLOW : RED;
  return (
    <div style={{ ...S.card, padding: 20 }}>
      <svg viewBox="0 0 200 110" style={{ width: '100%', maxWidth: 220, margin: '0 auto', display: 'block' }}>
        <path d="M 20 100 A 80 80 0 0 1 180 100" fill="none" stroke="#21262d" strokeWidth="12" strokeLinecap="round" />
        <path d="M 20 100 A 80 80 0 0 1 60 35" fill="none" stroke={RED} strokeWidth="12" strokeLinecap="round" opacity="0.3" />
        <path d="M 60 35 A 80 80 0 0 1 140 35" fill="none" stroke={YELLOW} strokeWidth="12" strokeLinecap="round" opacity="0.3" />
        <path d="M 140 35 A 80 80 0 0 1 180 100" fill="none" stroke={GREEN} strokeWidth="12" strokeLinecap="round" opacity="0.3" />
        <line x1="100" y1="100" x2={100 + 65 * Math.cos(Math.PI - (angle * Math.PI / 180))} y2={100 - 65 * Math.sin(Math.PI - (angle * Math.PI / 180))} stroke={c} strokeWidth="3" strokeLinecap="round" />
        <circle cx="100" cy="100" r="5" fill={c} />
        <text x="20" y="108" fill="#8b949e" fontSize="8" fontFamily="monospace">0.5</text>
        <text x="92" y="25" fill="#8b949e" fontSize="8" fontFamily="monospace">1.0</text>
        <text x="170" y="108" fill="#8b949e" fontSize="8" fontFamily="monospace">1.5</text>
      </svg>
      <div style={{ ...S.mono, fontSize: 28, fontWeight: 700, color: c, marginTop: -8 }}>{pcr.toFixed(3)}</div>
      <div style={{ fontSize: 11, fontWeight: 600, color: c, letterSpacing: '2px', marginTop: 2 }}>{label}</div>
    </div>
  );
}

function SectionHead({ icon, title, right }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid #21262d', paddingBottom: 8, marginTop: 22, marginBottom: 12 }}>
      <span style={{ color: BLUE, ...S.mono, fontSize: 12, fontWeight: 600 }}>{icon} {title}</span>
      {right && <span style={{ color: '#8b949e', fontSize: 10 }}>{right}</span>}
    </div>
  );
}

// ============================================================
// LOGIN SCREEN
// ============================================================
function LoginScreen({ loginUrl }) {
  return (
    <div style={{ ...S.app, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '100vh', padding: 32 }}>
      <div style={{ fontSize: 48, marginBottom: 16 }}>🎯</div>
      <h1 style={{ ...S.mono, color: BLUE, fontSize: 24, fontWeight: 800, marginBottom: 8 }}>OI RADAR</h1>
      <p style={{ color: '#8b949e', fontSize: 14, textAlign: 'center', marginBottom: 32, lineHeight: 1.6 }}>
        Live Options OI Buildup Analysis<br />for NIFTY &amp; BANKNIFTY
      </p>
      <a href={loginUrl} style={{
        background: 'linear-gradient(135deg, #1f6feb, #388bfd)', color: '#fff',
        padding: '14px 32px', borderRadius: 10, fontSize: 14, fontWeight: 600,
        textDecoration: 'none', ...S.mono,
      }}>
        LOGIN WITH UPSTOX →
      </a>
      <p style={{ color: '#6e7681', fontSize: 11, marginTop: 16, textAlign: 'center' }}>
        One-time daily login • Free API • Your data stays private
      </p>
    </div>
  );
}

// ============================================================
// MAIN DASHBOARD
// ============================================================
export default function Dashboard() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [loginUrl, setLoginUrl] = useState(null);
  const [symbol, setSymbol] = useState('NIFTY');
  const [tab, setTab] = useState('oi');
  const [lastUpdate, setLastUpdate] = useState(null);
  const [refreshing, setRefreshing] = useState(false);
  const timerRef = useRef(null);
  const REFRESH_INTERVAL = 30000; // 30 seconds

  const fetchData = useCallback(async (isManual = false) => {
    if (isManual) setRefreshing(true);
    try {
      const res = await fetch(`/api/oi?symbol=${symbol}`);
      const json = await res.json();

      if (res.status === 401) {
        setLoginUrl(json.loginUrl);
        setLoading(false);
        return;
      }
      if (!res.ok) throw new Error(json.message || 'Failed to fetch');

      setData(json);
      setLoginUrl(null);
      setError(null);
      setLastUpdate(new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [symbol]);

  // Initial fetch + auto-refresh
  useEffect(() => {
    setLoading(true);
    fetchData();
    timerRef.current = setInterval(() => fetchData(), REFRESH_INTERVAL);
    return () => clearInterval(timerRef.current);
  }, [fetchData]);

  // Show login screen
  if (loginUrl) return <LoginScreen loginUrl={loginUrl} />;

  // Loading state
  if (loading && !data) {
    return (
      <div style={{ ...S.app, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '100vh' }}>
        <div className="spinner" />
        <p style={{ color: '#8b949e', marginTop: 16, ...S.mono, fontSize: 12 }}>Fetching OI data...</p>
      </div>
    );
  }

  if (error && !data) {
    return (
      <div style={{ ...S.app, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '100vh', padding: 32 }}>
        <div style={{ fontSize: 36, marginBottom: 12 }}>⚠️</div>
        <p style={{ color: RED, ...S.mono, fontSize: 13 }}>{error}</p>
        <button onClick={() => { setLoading(true); fetchData(); }} style={{ ...S.btn(true), marginTop: 16, padding: '12px 24px' }}>RETRY</button>
      </div>
    );
  }

  if (!data) return null;

  // Process data for display
  const { spot, totals, strikes, expiry, maxPain } = data;
  const step = symbol === 'BANKNIFTY' ? 100 : 50;
  const atmStrike = Math.round(spot / step) * step;
  const nearby = strikes
    .filter(s => Math.abs(s.strike - atmStrike) <= 12 * step)
    .sort((a, b) => a.strike - b.strike);
  const maxChange = Math.max(...nearby.map(s => Math.max(Math.abs(s.ceChange), Math.abs(s.peChange))), 1);

  // Support / Resistance
  const resistance = [...strikes].sort((a, b) => b.ceOI - a.ceOI).slice(0, 5)
    .map(s => ({ strike: s.strike, oi: s.ceOI, change: s.ceChange, distance: ((s.strike - spot) / spot * 100).toFixed(1) }));
  const support = [...strikes].sort((a, b) => b.peOI - a.peOI).slice(0, 5)
    .map(s => ({ strike: s.strike, oi: s.peOI, change: s.peChange, distance: ((spot - s.strike) / spot * 100).toFixed(1) }));

  // Buildups
  const buildups = nearby.flatMap(s => {
    const items = [];
    const threshold = symbol === 'BANKNIFTY' ? 50000 : 100000;
    for (const [type, change, oi] of [['CE', s.ceChange, s.ceOI], ['PE', s.peChange, s.peOI]]) {
      if (Math.abs(change) > threshold) {
        items.push({
          strike: s.strike, type, change, oi,
          signal: change > threshold * 2 ? 'FRESH WRITING' : change > 0 ? 'AGGRESSIVE' : 'UNWINDING',
        });
      }
    }
    return items;
  }).sort((a, b) => Math.abs(b.change) - Math.abs(a.change)).slice(0, 10);

  const sentiment = totals.peChange > totals.ceChange ? 'BULLISH' : totals.ceChange > totals.peChange ? 'BEARISH' : 'NEUTRAL';
  const sentColor = sentiment === 'BULLISH' ? GREEN : sentiment === 'BEARISH' ? RED : YELLOW;

  const tabs = [
    { id: 'oi', label: 'OI MAP' },
    { id: 'buildup', label: 'BUILDUP' },
    { id: 'sr', label: 'S / R' },
    { id: 'pcr', label: 'PCR' },
  ];

  return (
    <div style={S.app}>
      {/* ===== HEADER ===== */}
      <div style={S.header}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <div style={{ ...S.mono, fontSize: 18, fontWeight: 800, color: BLUE }}>🎯 OI RADAR</div>
            <div style={{ fontSize: 10, color: '#8b949e', marginTop: 1 }}>
              {expiry} • <span className={refreshing ? 'refreshing' : ''} style={{ cursor: 'pointer' }} onClick={() => fetchData(true)}>⟳</span> {lastUpdate}
            </div>
          </div>
          <div style={{ display: 'flex', gap: 5 }}>
            {['NIFTY', 'BANKNIFTY'].map(s => (
              <button key={s} onClick={() => setSymbol(s)} style={S.btn(symbol === s)}>
                {s === 'BANKNIFTY' ? 'BNIFTY' : s}
              </button>
            ))}
          </div>
        </div>

        <div style={{ display: 'flex', gap: 6, marginTop: 10 }}>
          <MetricCard label="SPOT" value={spot?.toLocaleString('en-IN', { maximumFractionDigits: 1 })} color={BLUE} />
          <MetricCard label="PCR" value={totals.pcr.toFixed(3)} color={totals.pcr > 0.9 ? GREEN : totals.pcr < 0.7 ? RED : YELLOW} />
          <MetricCard label="SIGNAL" value={sentiment} color={sentColor} />
          <MetricCard label="MAX PAIN" value={maxPain?.toLocaleString('en-IN')} color={YELLOW} />
        </div>
      </div>

      {/* ===== TABS ===== */}
      <div style={{ display: 'flex', padding: '6px 16px', background: '#0d1117', borderBottom: '1px solid #21262d', position: 'sticky', top: 130, zIndex: 99 }}>
        {tabs.map(t => <button key={t.id} onClick={() => setTab(t.id)} style={S.tab(tab === t.id)}>{t.label}</button>)}
      </div>

      <div style={{ padding: '0 12px' }}>

        {/* ===== OI MAP ===== */}
        {tab === 'oi' && (
          <>
            <SectionHead icon="📊" title="OI CHANGE HEATMAP" right={`${nearby.length} strikes`} />
            <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 10px', fontSize: 9, color: '#8b949e', ...S.mono }}>
              <span style={{ color: RED }}>◄ CE OI CHG</span>
              <span>STRIKE</span>
              <span style={{ color: GREEN }}>PE OI CHG ►</span>
            </div>
            <div style={{ background: '#0d1117', borderRadius: 10, border: '1px solid #21262d', overflow: 'hidden' }}>
              {nearby.map(s => (
                <OIBar key={s.strike} strike={s.strike} ceChange={s.ceChange} peChange={s.peChange} maxChange={maxChange} isATM={s.strike === atmStrike} />
              ))}
            </div>
            <div style={{ display: 'flex', gap: 6, marginTop: 12 }}>
              <MetricCard label="NET CE OI CHG" value={fmtS(totals.ceChange)} color={totals.ceChange > 0 ? RED : GREEN} sub="Resistance pressure" />
              <MetricCard label="NET PE OI CHG" value={fmtS(totals.peChange)} color={totals.peChange > 0 ? GREEN : RED} sub="Support base" />
            </div>
          </>
        )}

        {/* ===== BUILDUP ===== */}
        {tab === 'buildup' && (
          <>
            <SectionHead icon="🔥" title="OI BUILDUP" right="By activity" />
            <div style={{ background: '#0d111766', borderRadius: 8, padding: 10, marginBottom: 12, fontSize: 11, color: '#8b949e', lineHeight: 1.7 }}>
              <span style={{ color: GREEN }}>FRESH WRITING</span> = Big new positions (strong signal) &nbsp;
              <span style={{ color: RED }}>AGGRESSIVE</span> = Adding to positions &nbsp;
              <span style={{ color: YELLOW }}>UNWINDING</span> = Exiting
            </div>
            {buildups.length > 0 ? buildups.map((b, i) => <BuildupRow key={i} {...b} />) :
              <div style={{ textAlign: 'center', color: '#8b949e', padding: 40 }}>No significant OI buildup</div>}
          </>
        )}

        {/* ===== SUPPORT / RESISTANCE ===== */}
        {tab === 'sr' && (
          <>
            <SectionHead icon="🔴" title="RESISTANCE (Max CE OI)" />
            {resistance.map((r, i) => <SRLevel key={i} {...r} type="resistance" />)}
            <SectionHead icon="🟢" title="SUPPORT (Max PE OI)" />
            {support.map((s, i) => <SRLevel key={i} {...s} type="support" />)}

            {/* Range visualizer */}
            <div style={{ ...S.card, marginTop: 16, padding: 16 }}>
              <div style={{ fontSize: 12, color: BLUE, fontWeight: 600, marginBottom: 10 }}>📐 OI-BASED RANGE</div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ textAlign: 'center' }}>
                  <div style={{ ...S.mono, fontSize: 18, fontWeight: 700, color: GREEN }}>{support[0]?.strike}</div>
                  <div style={{ fontSize: 10, color: '#8b949e' }}>SUPPORT</div>
                </div>
                <div style={{ flex: 1, height: 4, background: `linear-gradient(90deg, ${GREEN}, ${BLUE}, ${RED})`, borderRadius: 2, margin: '0 14px', position: 'relative' }}>
                  <div style={{ position: 'absolute', top: -10, left: '50%', transform: 'translateX(-50%)', ...S.mono, fontSize: 10, color: BLUE }}>▼ {spot?.toFixed(0)}</div>
                </div>
                <div style={{ textAlign: 'center' }}>
                  <div style={{ ...S.mono, fontSize: 18, fontWeight: 700, color: RED }}>{resistance[0]?.strike}</div>
                  <div style={{ fontSize: 10, color: '#8b949e' }}>RESISTANCE</div>
                </div>
              </div>
              <div style={{ textAlign: 'center', marginTop: 12, ...S.mono, fontSize: 12, color: YELLOW }}>
                Max Pain: {maxPain?.toLocaleString('en-IN')}
              </div>
            </div>
          </>
        )}

        {/* ===== PCR ===== */}
        {tab === 'pcr' && (
          <>
            <SectionHead icon="📈" title="PUT-CALL RATIO" />
            <PCRGauge pcr={totals.pcr} />
            <div style={{ display: 'flex', gap: 6, marginTop: 12 }}>
              <MetricCard label="TOTAL CE OI" value={fmt(totals.ceOI)} color={RED} />
              <MetricCard label="TOTAL PE OI" value={fmt(totals.peOI)} color={GREEN} />
            </div>
            <div style={{ display: 'flex', gap: 6, marginTop: 6 }}>
              <MetricCard label="CE OI CHG" value={fmtS(totals.ceChange)} color={RED} />
              <MetricCard label="PE OI CHG" value={fmtS(totals.peChange)} color={GREEN} />
            </div>
            <div style={{ display: 'flex', gap: 6, marginTop: 6 }}>
              <MetricCard label="CE VOLUME" value={fmt(totals.ceVol)} color="#8b949e" />
              <MetricCard label="PE VOLUME" value={fmt(totals.peVol)} color="#8b949e" />
            </div>
            <div style={{ ...S.card, marginTop: 14, textAlign: 'left', padding: 16 }}>
              <div style={{ fontSize: 12, color: BLUE, fontWeight: 600, marginBottom: 8 }}>🧠 INTERPRETATION</div>
              <div style={{ fontSize: 12, lineHeight: 1.8 }}>
                {totals.pcr > 1.3 && '⚠️ PCR > 1.3 — Extreme zone. Put writers heavily positioned. Watch for reversal or acceleration.'}
                {totals.pcr > 0.9 && totals.pcr <= 1.3 && '🟢 PCR 0.9-1.3 — Bullish zone. PE writers confident about support. Trend likely continues up.'}
                {totals.pcr > 0.7 && totals.pcr <= 0.9 && '🟡 PCR 0.7-0.9 — Neutral. Market balanced. Wait for OI buildup to confirm.'}
                {totals.pcr <= 0.7 && '🔴 PCR < 0.7 — Bearish. CE writers dominating. Strong resistance overhead.'}
              </div>
            </div>
          </>
        )}

        {/* Footer */}
        <div style={{ textAlign: 'center', padding: '24px 0', color: '#30363d', fontSize: 9, borderTop: '1px solid #21262d', marginTop: 24 }}>
          OI RADAR v1.0 • Auto-refresh 30s • Powered by Upstox API
        </div>
      </div>
    </div>
  );
}
