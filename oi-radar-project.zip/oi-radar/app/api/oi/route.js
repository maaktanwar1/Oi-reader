import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';

const INSTRUMENT_KEYS = {
  NIFTY: 'NSE_INDEX|Nifty 50',
  BANKNIFTY: 'NSE_INDEX|Nifty Bank',
  FINNIFTY: 'NSE_INDEX|Nifty Fin Service',
  MIDCPNIFTY: 'NSE_INDEX|NIFTY MID SELECT',
  SENSEX: 'BSE_INDEX|SENSEX',
};

export async function GET(request) {
  const cookieStore = await cookies();
  const token = cookieStore.get('upstox_token')?.value;

  if (!token) {
    return NextResponse.json({ error: 'not_authenticated', loginUrl: getLoginUrl() }, { status: 401 });
  }

  const { searchParams } = new URL(request.url);
  const symbol = searchParams.get('symbol') || 'NIFTY';
  const expiry = searchParams.get('expiry'); // optional, if not provided we fetch expiries first

  const instrumentKey = INSTRUMENT_KEYS[symbol] || INSTRUMENT_KEYS.NIFTY;
  const headers = {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`,
  };

  try {
    // Step 1: If no expiry provided, fetch available expiries first
    let expiryDate = expiry;
    if (!expiryDate) {
      const contractRes = await fetch(
        `https://api.upstox.com/v2/option/contract?instrument_key=${encodeURIComponent(instrumentKey)}`,
        { headers, next: { revalidate: 300 } } // cache 5 min
      );
      const contractData = await contractRes.json();

      if (contractData.status !== 'success' || !contractData.data?.length) {
        return NextResponse.json({ error: 'no_contracts', message: 'Could not fetch option contracts' }, { status: 500 });
      }

      // Get unique expiry dates, sorted ascending
      const expiries = [...new Set(contractData.data.map(c => c.expiry))].sort();
      expiryDate = expiries[0]; // nearest expiry

      // Return expiries list along with data if requested
      if (searchParams.get('expiries_only') === 'true') {
        return NextResponse.json({ expiries });
      }
    }

    // Step 2: Fetch option chain for the expiry
    const chainRes = await fetch(
      `https://api.upstox.com/v2/option/chain?instrument_key=${encodeURIComponent(instrumentKey)}&expiry_date=${expiryDate}`,
      { headers, cache: 'no-store' } // always fresh
    );
    const chainData = await chainRes.json();

    if (chainData.status !== 'success' || !chainData.data?.length) {
      // Token might be expired
      if (chainRes.status === 401) {
        return NextResponse.json({ error: 'token_expired', loginUrl: getLoginUrl() }, { status: 401 });
      }
      return NextResponse.json({ error: 'no_data', message: 'No option chain data available', raw: chainData }, { status: 500 });
    }

    // Step 3: Process the data
    const spot = chainData.data[0]?.underlying_spot_price || 0;
    let totalCeOI = 0, totalPeOI = 0, totalCeChange = 0, totalPeChange = 0;
    let totalCeVol = 0, totalPeVol = 0;

    const strikes = chainData.data.map(row => {
      const ce = row.call_options?.market_data || {};
      const pe = row.put_options?.market_data || {};
      const ceGreeks = row.call_options?.option_greeks || {};
      const peGreeks = row.put_options?.option_greeks || {};

      const ceOI = ce.oi || 0;
      const peOI = pe.oi || 0;
      const cePrevOI = ce.prev_oi || 0;
      const pePrevOI = pe.prev_oi || 0;
      const ceChange = ceOI - cePrevOI;
      const peChange = peOI - pePrevOI;

      totalCeOI += ceOI;
      totalPeOI += peOI;
      totalCeChange += ceChange;
      totalPeChange += peChange;
      totalCeVol += (ce.volume || 0);
      totalPeVol += (pe.volume || 0);

      return {
        strike: row.strike_price,
        ceOI, peOI,
        ceChange, peChange,
        cePrevOI, pePrevOI,
        ceVol: ce.volume || 0,
        peVol: pe.volume || 0,
        ceLTP: ce.ltp || 0,
        peLTP: pe.ltp || 0,
        ceIV: ceGreeks.iv || 0,
        peIV: peGreeks.iv || 0,
        ceDelta: ceGreeks.delta || 0,
        peDelta: peGreeks.delta || 0,
        ceGamma: ceGreeks.gamma || 0,
        ceTheta: ceGreeks.theta || 0,
        ceVega: ceGreeks.vega || 0,
        ceBid: ce.bid_price || 0,
        ceAsk: ce.ask_price || 0,
        peBid: pe.bid_price || 0,
        peAsk: pe.ask_price || 0,
      };
    }).sort((a, b) => a.strike - b.strike);

    const pcr = totalCeOI > 0 ? (totalPeOI / totalCeOI) : 0;

    // Max Pain calculation
    let minPain = Infinity;
    let maxPainStrike = 0;
    for (const s of strikes) {
      let pain = 0;
      for (const t of strikes) {
        if (t.strike < s.strike) pain += t.ceOI * (s.strike - t.strike);
        if (t.strike > s.strike) pain += t.peOI * (t.strike - s.strike);
      }
      if (pain < minPain) {
        minPain = pain;
        maxPainStrike = s.strike;
      }
    }

    return NextResponse.json({
      symbol,
      spot,
      expiry: expiryDate,
      timestamp: new Date().toISOString(),
      maxPain: maxPainStrike,
      strikes,
      totals: {
        ceOI: totalCeOI,
        peOI: totalPeOI,
        ceChange: totalCeChange,
        peChange: totalPeChange,
        ceVol: totalCeVol,
        peVol: totalPeVol,
        pcr: Math.round(pcr * 1000) / 1000,
      },
    });
  } catch (error) {
    console.error('OI fetch error:', error);
    return NextResponse.json({ error: 'fetch_failed', message: error.message }, { status: 500 });
  }
}

function getLoginUrl() {
  return `https://api.upstox.com/v2/login/authorization/dialog?response_type=code&client_id=${process.env.UPSTOX_API_KEY}&redirect_uri=${encodeURIComponent(process.env.UPSTOX_REDIRECT_URI)}`;
}
